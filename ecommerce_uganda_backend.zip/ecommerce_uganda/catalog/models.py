from decimal import Decimal

from django.db import models
from django.conf import settings
from django.core.exceptions import ValidationError


class Product(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=12, decimal_places=2)
    cost_price = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    seller_floor = models.DecimalField(
        max_digits=12, decimal_places=2, null=True, blank=True,
        help_text="Absolute minimum acceptable price during negotiation. "
                   "Must be at least MINIMUM_MARGIN_PERCENT above cost_price. "
                   "Never shown to customers."
    )
    stock = models.PositiveIntegerField(default=0)
    category = models.CharField(max_length=100, blank=True)
    image = models.ImageField(upload_to='products/', blank=True, null=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='created_products',
        limit_choices_to={'role': 'admin'}
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.name

    @property
    def is_in_stock(self):
        return self.stock > 0

    @property
    def minimum_allowed_floor(self):
        """
        The lowest seller_floor can legally be, given cost_price and the
        configured minimum margin. This is the actual safety boundary —
        everything else (admin UI, serializers, the negotiation engine)
        just surfaces or defers to this number.

        MINIMUM_MARGIN_PERCENT is stored as a fraction (0.10 = 10%),
        matching COMMISSION_RATE's existing convention in this project.
        """
        margin_fraction = Decimal(str(getattr(settings, 'MINIMUM_MARGIN_PERCENT', 0.10)))
        return (self.cost_price * (Decimal('1') + margin_fraction)).quantize(Decimal('0.01'))

    def clean(self):
        super().clean()
        if self.seller_floor is not None and self.seller_floor < self.minimum_allowed_floor:
            margin_percent_display = getattr(settings, 'MINIMUM_MARGIN_PERCENT', 0.10) * 100
            raise ValidationError({
                'seller_floor': (
                    f"Seller floor must be at least {self.minimum_allowed_floor} "
                    f"(cost price + {margin_percent_display:.0f}% minimum margin)."
                )
            })

    def save(self, *args, **kwargs):
        # full_clean() (not just clean()) so this fires on every save path,
        # including direct .save() calls that skip a serializer/form's own
        # validate() — this rule can't be silently bypassed.
        self.full_clean()
        super().save(*args, **kwargs)
