from django.urls import path

from .views import (
    AgentCommissionListView,
    AgentTopUpCustomerView,
    GatewayTopUpCallbackView,
    GatewayTopUpInitiateView,
    GatewayTopUpStatusView,
    WalletDetailView,
    WalletTransactionListView,
)

urlpatterns = [
    path('', WalletDetailView.as_view(), name='wallet-detail'),
    path('transactions/', WalletTransactionListView.as_view(), name='wallet-transactions'),
    path('topup/', GatewayTopUpInitiateView.as_view(), name='wallet-topup'),
    path('topup/<int:pk>/status/', GatewayTopUpStatusView.as_view(), name='wallet-topup-status'),
    path('topup/callback/<str:provider>/', GatewayTopUpCallbackView.as_view(), name='wallet-topup-callback'),
    path('agent/topup-customer/', AgentTopUpCustomerView.as_view(), name='agent-topup-customer'),
    path('agent/commissions/', AgentCommissionListView.as_view(), name='agent-commissions'),
]
