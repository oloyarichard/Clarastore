import uuid
from decimal import Decimal

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import transaction

from .gateways import GatewayError, get_gateway
from .models import AgentCommission, TopUpRequest, Wallet, WalletTransaction


def calculate_commissions(order):
    """
    Called when an order transitions to 'delivered'. Credits the assigned
    agent 10% of profit on every item in the order. Idempotent: items that
    already have a linked AgentCommission are skipped, so calling this twice
    for the same order never double-pays.
    """
    agent = order.assigned_agent
    if not agent:
        return

    rate = Decimal(str(settings.COMMISSION_RATE))

    with transaction.atomic():
        wallet, _ = Wallet.objects.get_or_create(user=agent)
        wallet = Wallet.objects.select_for_update().get(pk=wallet.pk)

        for item in order.items.select_related('product').all():
            if hasattr(item, 'commission'):
                continue  # already paid out

            profit_per_unit = item.price_at_purchase - item.product.cost_price
            profit_amount = (profit_per_unit * item.quantity).quantize(Decimal('0.01'))
            commission_amount = (profit_amount * rate).quantize(Decimal('0.01'))

            wallet.balance += commission_amount
            wallet.save(update_fields=['balance'])

            wallet_txn = WalletTransaction.objects.create(
                wallet=wallet,
                type='commission',
                amount=commission_amount,
                balance_after=wallet.balance,
                reference=f"ORDER_{order.id}_ITEM_{item.id}",
            )
            AgentCommission.objects.create(
                order_item=item,
                agent=agent,
                profit_amount=profit_amount,
                commission_amount=commission_amount,
                wallet_transaction=wallet_txn,
            )


def process_refund(order):
    """
    Refund the full order total back to the customer's wallet. Called when
    a flagged order is resolved as 'lost'.
    """
    with transaction.atomic():
        wallet = Wallet.objects.select_for_update().get(user=order.customer)
        wallet.balance += order.total_amount
        wallet.save(update_fields=['balance'])
        WalletTransaction.objects.create(
            wallet=wallet,
            type='refund',
            amount=order.total_amount,
            balance_after=wallet.balance,
            reference=f"ORDER_{order.id}_REFUND",
        )


def agent_topup_customer(agent, customer, amount):
    """
    Move `amount` from the agent's own wallet to a customer's wallet
    (agent collected cash in person and is crediting the customer's
    account). Blocked if it would drop the agent below the required
    standing minimum float (AGENT_MINIMUM_FLOAT) — the agent must always
    keep at least that much available, not just reach it once.
    """
    if amount <= 0:
        raise ValidationError("Amount must be positive.")

    min_float = Decimal(str(settings.AGENT_MINIMUM_FLOAT))
    reference = str(uuid.uuid4())

    with transaction.atomic():
        agent_wallet = Wallet.objects.select_for_update().get(user=agent)
        customer_wallet = Wallet.objects.select_for_update().get(user=customer)

        if agent_wallet.balance - amount < min_float:
            raise ValidationError(
                f"This would drop your float below the required minimum of "
                f"{min_float}. Top up your own wallet first."
            )

        agent_wallet.balance -= amount
        agent_wallet.save(update_fields=['balance'])
        WalletTransaction.objects.create(
            wallet=agent_wallet,
            type='topup_via_agent_debit',
            amount=-amount,
            balance_after=agent_wallet.balance,
            reference=reference,
            created_by=agent,
        )

        customer_wallet.balance += amount
        customer_wallet.save(update_fields=['balance'])
        WalletTransaction.objects.create(
            wallet=customer_wallet,
            type='topup_via_agent_credit',
            amount=amount,
            balance_after=customer_wallet.balance,
            reference=reference,
            created_by=agent,
        )

    return reference


def initiate_gateway_topup(user, amount, phone_number, provider):
    """
    Starts a mobile money top-up: asks MTN MoMo or Airtel Money to push a
    payment request to the customer's phone. Nothing is credited yet — the
    customer still has to approve the PIN prompt on their device. Returns
    the TopUpRequest record the client should poll (or wait on a callback
    for) to find out the outcome.
    """
    if amount <= 0:
        raise ValidationError("Amount must be positive.")
    if provider not in dict(TopUpRequest.PROVIDER_CHOICES):
        raise ValidationError(f"Unknown provider: {provider}")

    external_id = str(uuid.uuid4())
    gateway = get_gateway(provider)

    try:
        reference_id = gateway.request_payment(phone_number, amount, external_id)
    except GatewayError as e:
        raise ValidationError(str(e))

    return TopUpRequest.objects.create(
        user=user,
        provider=provider,
        phone_number=phone_number,
        amount=amount,
        external_reference=reference_id,
        status='pending',
    )


def confirm_gateway_topup(topup_request):
    """
    Checks the current status of a pending TopUpRequest with the provider
    and, on success, credits the wallet exactly once. Safe to call
    repeatedly while polling — once a request is no longer 'pending' this
    is a no-op. Returns the (possibly updated) TopUpRequest.
    """
    if topup_request.status != 'pending':
        return topup_request

    gateway = get_gateway(topup_request.provider)
    try:
        provider_status = gateway.check_status(topup_request.external_reference)
    except GatewayError as e:
        raise ValidationError(str(e))

    if provider_status == 'pending':
        return topup_request

    with transaction.atomic():
        # Re-fetch and lock so two concurrent status checks can't both credit.
        topup_request = TopUpRequest.objects.select_for_update().get(pk=topup_request.pk)
        if topup_request.status != 'pending':
            return topup_request

        if provider_status == 'successful':
            wallet, _ = Wallet.objects.get_or_create(user=topup_request.user)
            wallet = Wallet.objects.select_for_update().get(pk=wallet.pk)
            wallet.balance += topup_request.amount
            wallet.save(update_fields=['balance'])

            wallet_txn = WalletTransaction.objects.create(
                wallet=wallet,
                type='topup_gateway',
                amount=topup_request.amount,
                balance_after=wallet.balance,
                reference=f"{topup_request.provider}:{topup_request.external_reference}",
            )
            topup_request.status = 'successful'
            topup_request.wallet_transaction = wallet_txn
        else:
            topup_request.status = 'failed'

        topup_request.save(update_fields=['status', 'wallet_transaction', 'updated_at'])

    return topup_request
