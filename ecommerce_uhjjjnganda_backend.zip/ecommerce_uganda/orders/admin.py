from django.contrib import admin
from .models import CartItem, Order, OrderItem


@admin.register(CartItem)
class CartItemAdmin(admin.ModelAdmin):
    list_display = ['user', 'session_key', 'product', 'quantity', 'created_at']
    list_filter = ['created_at']
    search_fields = ['user__username', 'product__name', 'session_key']

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user', 'product')


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ['subtotal']

    def subtotal(self, obj):
        return obj.subtotal


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = [
        'id', 'customer', 'district', 'hub', 'assigned_agent',
        'status', 'total_amount', 'payment_status', 'created_at'
    ]
    list_filter = ['status', 'payment_status', 'district', 'hub', 'created_at']
    search_fields = ['customer__username', 'id', 'transport_reference']
    readonly_fields = ['created_at', 'dispatched_at', 'delivered_at']
    inlines = [OrderItemInline]

    def get_queryset(self, request):
        return super().get_queryset(request).select_related(
            'customer', 'district', 'hub', 'assigned_agent'
        )

    def changelist_view(self, request, extra_context=None):
        # Add a quick link to flagged orders
        extra_context = extra_context or {}
        extra_context['flagged_count'] = Order.objects.filter(status='flagged').count()
        return super().changelist_view(request, extra_context=extra_context)


@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ['order', 'product', 'quantity', 'price_at_purchase', 'subtotal']
    list_filter = ['order__status']
    search_fields = ['order__id', 'product__name']

    def subtotal(self, obj):
        return obj.subtotal

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('order', 'product')
