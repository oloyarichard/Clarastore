from rest_framework import generics, status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from django.db import transaction

from .models import User, District
from .serializers import (
    UserRegistrationSerializer,
    UserSerializer,
    DistrictSerializer,
    AgentCreateSerializer,
)
from .permissions import IsAdmin


class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserRegistrationSerializer
    permission_classes = [AllowAny]

    @transaction.atomic
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()

        # Create wallet for new customer
        from wallets.models import Wallet
        Wallet.objects.get_or_create(user=user, defaults={'balance': 0})

        return Response({
            'user': UserSerializer(user).data,
            'message': 'User registered successfully.'
        }, status=status.HTTP_201_CREATED)


class LoginView(TokenObtainPairView):
    permission_classes = [AllowAny]


class RefreshView(TokenRefreshView):
    pass


class ProfileView(generics.RetrieveUpdateAPIView):
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user


class DistrictListView(generics.ListAPIView):
    queryset = District.objects.all()
    serializer_class = DistrictSerializer
    permission_classes = [AllowAny]


class AgentCreateView(generics.CreateAPIView):
    queryset = User.objects.filter(role='agent')
    serializer_class = AgentCreateSerializer
    permission_classes = [IsAdmin]

    @transaction.atomic
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        agent = serializer.save()

        # Create wallet for new agent
        from wallets.models import Wallet
        Wallet.objects.get_or_create(user=agent, defaults={'balance': 0})

        return Response({
            'agent': UserSerializer(agent).data,
            'message': 'Agent created successfully.'
        }, status=status.HTTP_201_CREATED)
