from rest_framework import permissions


class IsAdmin(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.is_admin_role


class IsAgent(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.is_agent


class IsCustomer(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.is_customer


class IsOrderOwnerOrAgent(permissions.BasePermission):
    """
    Custom permission to only allow owners of an order or assigned agents to view it.
    """
    def has_object_permission(self, request, view, obj):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        if user.is_admin_role:
            return True
        if user.is_agent and obj.assigned_agent == user:
            return True
        if user.is_customer and obj.customer == user:
            return True
        return False
