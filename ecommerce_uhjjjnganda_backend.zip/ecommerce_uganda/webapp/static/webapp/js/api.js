// Same-origin deployment: Django serves both this frontend and the API,
// so a relative path works everywhere (dev, staging, production) without
// needing a config file per environment. Override window.API_BASE_URL
// before this script loads if you ever split them onto different hosts.
window.API_BASE_URL = window.API_BASE_URL || '/api';

class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.status = status;
    this.data = data;
  }
}

function extractErrorMessage(data) {
  if (!data) return null;
  if (data.error) return data.error;
  if (data.detail) return data.detail;
  const firstKey = Object.keys(data)[0];
  if (firstKey && Array.isArray(data[firstKey]) && data[firstKey].length) {
    return `${firstKey}: ${data[firstKey][0]}`;
  }
  return null;
}

function clearAuth() {
  localStorage.removeItem('access_token');
  localStorage.removeItem('refresh_token');
  localStorage.removeItem('user_role');
  localStorage.removeItem('user_id');
}

/**
 * Reads the `csrftoken` cookie Django sets (see base.html's {% csrf_token %}).
 * Not HttpOnly by design: Django's CSRF scheme relies on JS being able to
 * read this value and echo it back as a header, proving the request came
 * from a page that could read the site's own cookies (same-origin).
 */
function getCsrfToken() {
  const match = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : null;
}

const SAFE_METHODS = ['GET', 'HEAD', 'OPTIONS'];

async function tryRefresh() {
  const refresh = localStorage.getItem('refresh_token');
  if (!refresh) return false;
  try {
    const resp = await fetch(window.API_BASE_URL + '/auth/refresh/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh }),
    });
    if (!resp.ok) return false;
    const data = await resp.json();
    localStorage.setItem('access_token', data.access);
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Core request helper used by every page. `auth: false` skips attaching a
 * JWT (public endpoints); `credentials: 'include'` is always on so the
 * browser carries the Django session cookie automatically: that's what
 * lets a guest's cart persist across requests without any JS needing to
 * read the (HttpOnly) session cookie directly.
 */
async function apiFetch(path, { method = 'GET', body, auth = true, retry = true } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = localStorage.getItem('access_token');
  if (auth && token) headers['Authorization'] = 'Bearer ' + token;

  // Django's session-based auth (e.g. an admin also logged in via
  // /admin/ in the same browser) requires a CSRF token on every
  // unsafe-method request, even from JS: this is what makes that work.
  if (!SAFE_METHODS.includes(method.toUpperCase())) {
    const csrfToken = getCsrfToken();
    if (csrfToken) headers['X-CSRFToken'] = csrfToken;
  }

  let resp;
  try {
    resp = await fetch(window.API_BASE_URL + path, {
      method,
      headers,
      credentials: 'include',
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (networkError) {
    throw new ApiError('Could not reach the server. Check your connection and try again.', 0, null);
  }

  if (resp.status === 401 && retry && auth && token) {
    const refreshed = await tryRefresh();
    if (refreshed) {
      return apiFetch(path, { method, body, auth, retry: false });
    }
    clearAuth();
    throw new ApiError('Your session expired: please log in again.', 401, null);
  }

  const text = await resp.text();
  let data = null;
  if (text) {
    try { data = JSON.parse(text); } catch (e) { data = null; }
  }

  if (!resp.ok) {
    throw new ApiError(extractErrorMessage(data) || 'Something went wrong. Please try again.', resp.status, data);
  }

  return data;
}
