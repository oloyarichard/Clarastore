function isLoggedIn() {
  return !!localStorage.getItem('access_token');
}

function getRole() {
  return localStorage.getItem('user_role');
}

function isAgent() {
  return getRole() === 'agent';
}

/** Redirects to login if signed out, preserving the page to return to. */
function requireAuth() {
  if (!isLoggedIn()) {
    const next = encodeURIComponent(window.location.pathname + window.location.search);
    window.location.href = '/login/?next=' + next;
  }
}

function requireAgent() {
  requireAuth();
  if (!isAgent()) {
    window.location.href = '/shop/';
  }
}

async function login(email, password) {
  const data = await apiFetch('/auth/login/', { method: 'POST', body: { email, password }, auth: false });
  localStorage.setItem('access_token', data.access);
  localStorage.setItem('refresh_token', data.refresh);
  const profile = await apiFetch('/auth/profile/');
  localStorage.setItem('user_role', profile.role);
  localStorage.setItem('user_id', profile.id);
  await mergeGuestCart();
  return profile;
}

async function register(payload) {
  await apiFetch('/auth/register/', { method: 'POST', body: payload, auth: false });
  // Registration doesn't log the user in on the backend: log in right
  // after so the flow feels seamless, same as the Flutter app.
  return login(payload.email, payload.password);
}

/**
 * Merges whatever the guest added to their cart before signing in. No
 * session key needs to be passed: the backend reads it from the session
 * cookie the browser already sent along with this same request.
 */
async function mergeGuestCart() {
  try {
    await apiFetch('/cart/merge/', { method: 'POST', body: {} });
  } catch (e) {
    // Non-fatal: worst case the guest's pre-signup cart is empty or lost,
    // login itself still succeeds.
  }
}

function logout() {
  clearAuth();
  window.location.href = '/login/';
}

async function getCurrentUser() {
  if (!isLoggedIn()) return null;
  return apiFetch('/auth/profile/');
}
