from rest_framework.throttling import AnonRateThrottle


class LoginRateThrottle(AnonRateThrottle):
    """
    Throttles login attempts by IP address, regardless of whether the
    credentials being tried are valid. This is what actually slows down
    a brute-force/credential-stuffing attempt — there was previously no
    friction here at all, meaning an attacker could try passwords as
    fast as their connection allowed.
    """
    scope = 'login'
