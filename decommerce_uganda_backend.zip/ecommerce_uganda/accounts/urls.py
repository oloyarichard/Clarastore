from django.urls import path
from .views import RegisterView, LoginView, RefreshView, LogoutView, ProfileView, DistrictListView, AgentCreateView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='auth-register'),
    path('login/', LoginView.as_view(), name='auth-login'),
    path('refresh/', RefreshView.as_view(), name='auth-refresh'),
    path('logout/', LogoutView.as_view(), name='auth-logout'),
    path('profile/', ProfileView.as_view(), name='auth-profile'),
    path('districts/', DistrictListView.as_view(), name='district-list'),
    path('agents/', AgentCreateView.as_view(), name='agent-create'),
]
