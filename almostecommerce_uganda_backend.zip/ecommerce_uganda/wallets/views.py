from django.core.exceptions import ValidationError
from django.shortcuts import get_object_or_404
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.permissions import IsAgent
from . import services
from .models import AgentCommission, TopUpRequest, Wallet
from .serializers import (
    AgentCommissionSerializer,
    AgentTopUpSerializer,
    GatewayTopUpSerializer,
    TopUpRequestSerializer,
    WalletSerializer,
    WalletTransactionSerializer,
)


class WalletDetailView(generics.RetrieveAPIView):
    serializer_class = WalletSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        wallet, _ = Wallet.objects.get_or_create(user=self.request.user)
        return wallet


class WalletTransactionListView(generics.ListAPIView):
    serializer_class = WalletTransactionSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        wallet, _ = Wallet.objects.get_or_create(user=self.request.user)
        return wallet.transactions.all()


class GatewayTopUpInitiateView(APIView):
    """
    Disabled — wallet balances are now managed exclusively through
    Django admin ("the console"), not self-service top-up. Kept in
    place rather than deleted, so restoring self-service later is a
    small, reversible change.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        return Response(
            {"error": "Wallet top-ups are currently managed by admin only. Please contact support."},
            status=status.HTTP_403_FORBIDDEN,
        )


class GatewayTopUpStatusView(APIView):
    """Client polls this with the TopUpRequest id to find out if a top-up succeeded."""
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        topup_request = get_object_or_404(TopUpRequest, pk=pk, user=request.user)
        try:
            topup_request = services.confirm_gateway_topup(topup_request)
        except ValidationError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

        return Response(TopUpRequestSerializer(topup_request).data)


class GatewayTopUpCallbackView(APIView):
    """
    Optional webhook receiver for providers that support callbacks instead
    of (or alongside) polling. TODO: verify the callback's authenticity
    per-provider (MTN and Airtel each have their own signature/header
    scheme) before calling confirm — this currently just re-checks status
    with the provider directly rather than trusting the payload, which is
    the safer default until that verification is wired up.
    """
    permission_classes = []
    authentication_classes = []

    def post(self, request, provider):
        # Different providers name this field differently — MTN/Airtel
        # use referenceId/reference, GosentePay uses ref.
        reference_id = (
            request.data.get('referenceId')
            or request.data.get('reference')
            or request.data.get('ref')
        )
        if not reference_id:
            return Response({"error": "Missing reference."}, status=status.HTTP_400_BAD_REQUEST)

        topup_request = get_object_or_404(TopUpRequest, external_reference=reference_id, provider=provider)
        try:
            services.confirm_gateway_topup(topup_request)
        except ValidationError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

        return Response({"message": "Processed."}, status=status.HTTP_200_OK)


class AgentTopUpCustomerView(APIView):
    """
    Disabled — wallet balances are now managed exclusively through
    Django admin, not via agent-collected cash top-ups. Kept in place
    rather than deleted, so restoring this later is a small, reversible
    change.
    """
    permission_classes = [IsAuthenticated, IsAgent]

    def post(self, request):
        return Response(
            {"error": "Customer top-ups are currently managed by admin only."},
            status=status.HTTP_403_FORBIDDEN,
        )


class AgentCommissionListView(generics.ListAPIView):
    serializer_class = AgentCommissionSerializer
    permission_classes = [IsAuthenticated, IsAgent]

    def get_queryset(self):
        return AgentCommission.objects.filter(agent=self.request.user)
