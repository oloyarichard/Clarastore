from django.conf import settings
from django.core.mail import send_mail


def _send(subject, message, to_email):
    """
    Thin wrapper around Django's send_mail — kept in one place so every
    notification goes through the same error handling. A failed email
    (bad SMTP config, network issue) must never break the actual
    financial transaction it's reporting on; callers should call this
    after the money has already moved, not as a precondition for it.
    """
    if not to_email:
        return False
    try:
        send_mail(
            subject=subject,
            message=message,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[to_email],
            fail_silently=True,
        )
        return True
    except Exception:
        # fail_silently=True already covers most SMTP-level errors, but
        # this is a deliberate last-resort net — a notification email
        # should never be the reason a refund appears to have crashed.
        return False


def send_refund_notification(order, amount):
    subject = f"Your refund for Order #{order.id} has been processed"
    message = (
        f"Hi {order.customer.username},\n\n"
        f"A refund of UGX {amount} for Order #{order.id} has been sent to your "
        f"mobile money account ({order.customer.phone}).\n\n"
        f"If you don't see it within a few minutes, please contact support.\n\n"
        f"— Clarastock"
    )
    return _send(subject, message, order.customer.email)


def send_commission_clawback_notification(agent, order, amount):
    subject = f"Commission reversed for Order #{order.id}"
    message = (
        f"Hi {agent.username},\n\n"
        f"Order #{order.id} has been refunded to the customer. Since your "
        f"commission of UGX {amount} on this order was already paid out, "
        f"it has been deducted from your wallet balance.\n\n"
        f"— Clarastock"
    )
    return _send(subject, message, agent.email)
