from decimal import Decimal, InvalidOperation

from django.conf import settings
from django.db.models import Sum
from django.utils import timezone

from catalog.models import Product
from orders.models import CartItem, OrderItem

from .ai_providers.base import AIProviderError
from .ai_providers.ollama_provider import OllamaProvider
from .models import MarketSnapshot, NegotiationOffer, NegotiationSession


def get_ai_provider():
    """Single place that decides which AIProvider implementation is
    active — swap this to change providers without touching anything
    else in the negotiation flow."""
    return OllamaProvider()


# ---------------------------------------------------------------------
# Market signals — internal-only for now, per the agreed priority order
# (internal volume first; exchange rate and seasonal signals are real
# fields on MarketSnapshot but intentionally left at neutral/0 until a
# real external source is wired in — see class docstring below).
# ---------------------------------------------------------------------

def calculate_market_snapshot(product: Product) -> MarketSnapshot:
    """
    Computes a fresh MarketSnapshot from real internal data only.
    Confidence is deliberately kept low/honest when there isn't much
    real history to base it on — per the spec's rule against pretending
    thin data is confident intelligence.
    """
    thirty_days_ago = timezone.now() - timezone.timedelta(days=30)

    units_sold_recent = OrderItem.objects.filter(
        product=product,
        order__created_at__gte=thirty_days_ago,
        order__payment_status='paid',
    ).aggregate(total=Sum('quantity'))['total'] or 0

    sales_velocity = units_sold_recent / 30.0

    # Demand proxy: how many active cart entries currently reference this
    # product, relative to stock. Crude but real — not fabricated. A
    # proper "views" signal would need a ProductView model that doesn't
    # exist yet; noted as a clear improvement, not silently invented here.
    active_cart_count = CartItem.objects.filter(product=product).count()
    demand_score = min(1.0, active_cart_count / 10.0) if active_cart_count else 0.0

    inventory_pressure = 0.0
    if product.stock > 0:
        # Higher when demand is high relative to what's left in stock.
        inventory_pressure = min(1.0, (active_cart_count + units_sold_recent) / max(product.stock, 1))
    elif active_cart_count > 0:
        inventory_pressure = 1.0

    # Not wired to a live source yet — left neutral on purpose rather
    # than inventing a number, exactly per the "don't pretend it's live"
    # rule. Revisit once a real UGX/USD feed and a seasonal calendar are
    # actually connected.
    exchange_rate_signal = 0.0
    seasonal_signal = 0.0

    # Confidence reflects how much real signal actually exists — a brand
    # new product with zero sales history gets a low number, honestly.
    confidence = min(1.0, (units_sold_recent + active_cart_count) / 20.0)

    # Configurable weighting, not hardcoded math scattered everywhere —
    # matches the spec's request for a tunable scoring system.
    weights = getattr(settings, 'MARKET_SIGNAL_WEIGHTS', {
        'demand': 0.40,
        'inventory': 0.25,
        'velocity_bonus_cap': 0.20,  # extra nudge from raw sales velocity, capped
        'exchange_rate': 0.10,
        'seasonal': 0.05,
    })

    velocity_component = min(sales_velocity / 5.0, 1.0) * weights['velocity_bonus_cap']
    composite = (
        demand_score * weights['demand']
        + inventory_pressure * weights['inventory']
        + velocity_component
        + exchange_rate_signal * weights['exchange_rate']
        + seasonal_signal * weights['seasonal']
    )
    # composite is roughly 0-1; map it onto a price adjustment band
    # bounded to +/-15% of the listed price so a thin/noisy signal can
    # never produce an irrational jump (spec's MAX_PRICE_CHANGE control).
    max_adjustment = Decimal('0.15')
    adjustment = (Decimal(str(composite)) - Decimal('0.5')) * 2 * max_adjustment
    calculated_market_price = (product.price * (Decimal('1') + adjustment)).quantize(Decimal('0.01'))

    # Never let the calculated price fall below the floor, even before
    # any AI is involved — this is a second, independent layer of the
    # same safety rule, not a replacement for the one in services below.
    floor = product.seller_floor or product.minimum_allowed_floor
    if calculated_market_price < floor:
        calculated_market_price = floor

    snapshot = MarketSnapshot.objects.create(
        product=product,
        sales_velocity=sales_velocity,
        demand_score=demand_score,
        inventory_pressure=inventory_pressure,
        exchange_rate_signal=exchange_rate_signal,
        seasonal_signal=seasonal_signal,
        calculated_market_price=calculated_market_price,
        confidence=confidence,
        expires_at=timezone.now() + timezone.timedelta(hours=6),
    )
    return snapshot


def get_fresh_snapshot(product: Product) -> MarketSnapshot:
    """Reuses the latest snapshot if still fresh, otherwise calculates a
    new one — this is the cache/cost-control boundary: negotiation calls
    never trigger signal recalculation themselves."""
    latest = product.market_snapshots.order_by('-generated_at').first()
    if latest and latest.is_fresh:
        return latest
    return calculate_market_snapshot(product)


# ---------------------------------------------------------------------
# THE absolute safety rule. Every AI response passes through this
# before anything is recorded, shown to a customer, or acted on.
# No code path may skip this function and act on raw AI output directly.
# ---------------------------------------------------------------------

def validate_and_sanitize_decision(product: Product, raw_output: dict) -> dict:
    """
    Takes whatever the AI returned — however malformed, however wrong —
    and returns a guaranteed-safe decision dict:
        {decision, price, message, confidence, reason_code, was_backend_overridden}

    Guarantees, unconditionally:
    - decision is always one of ACCEPT / COUNTER / REJECT
    - if decision is ACCEPT or COUNTER, price is always a valid Decimal
      that is >= seller_floor and <= the listed price
    - malformed AI output never propagates — it's converted to a safe
      REJECT rather than raising an exception that could leave the
      negotiation in an inconsistent state
    """
    floor = product.seller_floor or product.minimum_allowed_floor
    overridden = False

    decision = raw_output.get('decision')
    if decision not in ('ACCEPT', 'COUNTER', 'REJECT'):
        decision = 'REJECT'
        overridden = True

    price = None
    if decision in ('ACCEPT', 'COUNTER'):
        raw_price = raw_output.get('price')
        try:
            price = Decimal(str(raw_price))
            if price <= 0:
                raise InvalidOperation
        except (TypeError, InvalidOperation, ValueError):
            # Can't trust a price we can't even parse — fail safe.
            decision = 'REJECT'
            price = None
            overridden = True

    if decision in ('ACCEPT', 'COUNTER') and price is not None:
        if price < floor:
            # This is the one rule that can never be crossed. An AI
            # trying to accept or counter below the floor gets converted
            # to a COUNTER pinned exactly at the floor — never a silent
            # ACCEPT below it, and never just an error that drops the
            # customer's negotiation.
            decision = 'COUNTER'
            price = floor
            overridden = True
        elif price > product.price:
            # The AI shouldn't be counter-proposing above the original
            # listed price either — clamp back down.
            price = product.price
            overridden = True

    message = raw_output.get('message')
    if not isinstance(message, str) or not message.strip():
        message = "Let me get back to you on that." if decision == 'COUNTER' else (
            "I'm sorry, I can't accept that offer." if decision == 'REJECT' else "Deal!"
        )
        overridden = True

    confidence = raw_output.get('confidence', 0)
    try:
        confidence = float(confidence)
        confidence = max(0.0, min(1.0, confidence))
    except (TypeError, ValueError):
        confidence = 0.0

    return {
        'decision': decision,
        'price': price,
        'message': message,
        'confidence': confidence,
        'reason_code': raw_output.get('reason_code', '') if isinstance(raw_output.get('reason_code'), str) else '',
        'was_backend_overridden': overridden,
    }


# ---------------------------------------------------------------------
# Negotiation flow
# ---------------------------------------------------------------------

def start_negotiation(product: Product, user=None, session_key=None) -> NegotiationSession:
    snapshot = get_fresh_snapshot(product)
    return NegotiationSession.objects.create(
        product=product, user=user, session_key=session_key, market_snapshot=snapshot
    )


def _build_system_context(product: Product, snapshot: MarketSnapshot) -> str:
    floor = product.seller_floor or product.minimum_allowed_floor
    # `floor` is intentionally NOT included in the prompt sent to the AI —
    # per the spec, the customer (and by extension anything that could
    # leak into a customer-visible message) must never see internal
    # pricing values. The AI negotiates on tone and feel only; the actual
    # floor enforcement happens in validate_and_sanitize_decision, entirely
    # outside the AI's awareness. `floor` is computed here only so future
    # prompt tuning has it on hand without re-deriving it.
    return (
        "You are a friendly sales negotiator for an online clothing store in Uganda. "
        "A customer is negotiating the price of a product. Respond ONLY with a JSON object "
        'with exactly these fields: {"decision": "ACCEPT"|"COUNTER"|"REJECT", "price": number, '
        '"confidence": number between 0 and 1, "reason_code": short string, "message": a short, '
        "natural, non-repetitive sentence to show the customer.\n\n"
        f"Product: {product.name}\n"
        f"Listed price: {product.price} UGX\n"
        f"Market conditions score (0-1, higher = more demand): {snapshot.demand_score:.2f}\n\n"
        "Rules: Never go below what the business can accept — you will be told to counter "
        "instead if you try. Be warm and conversational, vary your wording, don't repeat the "
        "same phrases turn after turn. If the customer's offer is reasonably close to a fair "
        "price, consider accepting rather than squeezing for more."
    )


def submit_customer_offer(negotiation: NegotiationSession, amount: Decimal) -> NegotiationOffer:
    """
    Records the customer's offer, calls the AI, validates the response
    no matter what, records the AI's turn, and — if accepted — locks the
    price into the customer's cart. Returns the NegotiationOffer record
    for the AI's turn (the caller reads .decision/.message/.amount from it).
    """
    product = negotiation.product

    NegotiationOffer.objects.create(
        negotiation=negotiation, turn_type='customer_offer', amount=amount
    )

    history = []
    for offer in negotiation.offers.order_by('created_at'):
        if offer.turn_type == 'customer_offer':
            history.append({"role": "user", "content": f"I can pay {offer.amount} UGX."})
        else:
            history.append({"role": "assistant", "content": offer.message or ''})

    system_context = _build_system_context(product, negotiation.market_snapshot)

    try:
        raw_output = get_ai_provider().negotiate(system_context, history)
    except AIProviderError:
        # The AI being unreachable/broken must never crash the customer's
        # negotiation — fail safe to a REJECT-shaped response and let the
        # same validation path handle it uniformly.
        raw_output = {'decision': 'REJECT', 'message': ''}

    sanitized = validate_and_sanitize_decision(product, raw_output)

    ai_turn = NegotiationOffer.objects.create(
        negotiation=negotiation,
        turn_type='ai_response',
        amount=sanitized['price'],
        decision=sanitized['decision'],
        message=sanitized['message'],
        market_snapshot=negotiation.market_snapshot,
        raw_ai_output=raw_output if isinstance(raw_output, dict) else {},
        ai_proposed_price=_safe_decimal(raw_output.get('price')) if isinstance(raw_output, dict) else None,
        was_backend_overridden=sanitized['was_backend_overridden'],
    )

    if sanitized['decision'] == 'ACCEPT':
        _apply_agreement(negotiation, sanitized['price'])
    elif sanitized['decision'] == 'REJECT':
        negotiation.status = 'rejected'
        negotiation.save(update_fields=['status', 'updated_at'])

    return ai_turn


def _safe_decimal(value):
    try:
        return Decimal(str(value))
    except (TypeError, InvalidOperation, ValueError):
        return None


def _apply_agreement(negotiation: NegotiationSession, price: Decimal):
    negotiation.mark_agreed(price)

    product = negotiation.product
    lookup = {'product': product}
    if negotiation.user_id:
        lookup['user'] = negotiation.user
    else:
        lookup['session_key'] = negotiation.session_key

    cart_item, created = CartItem.objects.get_or_create(
        **lookup,
        defaults={'quantity': 1, 'negotiated_price': price, 'negotiation': negotiation},
    )
    if not created:
        # Product was already in their cart at the regular price — the
        # agreement now takes over that same line rather than creating a
        # confusing duplicate row.
        cart_item.negotiated_price = price
        cart_item.negotiation = negotiation
        cart_item.save(update_fields=['negotiated_price', 'negotiation', 'updated_at'])
