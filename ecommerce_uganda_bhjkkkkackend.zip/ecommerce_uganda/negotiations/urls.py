from django.urls import path

from .views import NegotiationDetailView, StartNegotiationView, SubmitOfferView

urlpatterns = [
    path('start/', StartNegotiationView.as_view(), name='negotiation-start'),
    path('<int:pk>/', NegotiationDetailView.as_view(), name='negotiation-detail'),
    path('<int:pk>/offer/', SubmitOfferView.as_view(), name='negotiation-offer'),
]
